import { defineConfig } from "cypress";
import * as dotenv from "dotenv";

dotenv.config();

export default defineConfig({
  e2e: {
    baseUrl: process.env.BASE_URL || "https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod",
    specPattern: "cypress/e2e/**/*.cy.ts",
    supportFile: "cypress/support/e2e.ts",
    setupNodeEvents(on, config) {
      config.env.UI_LOGIN_URL = process.env.UI_LOGIN_URL;
      config.env.TEST_USERNAME = process.env.TEST_USERNAME;
      config.env.TEST_PASSWORD = process.env.TEST_PASSWORD;
      config.env.AUTH_TOKEN = process.env.AUTH_TOKEN;
      return config;
    },
    viewportWidth: 1280,
    viewportHeight: 800,
    video: false,
    defaultCommandTimeout: 8000,
  },
});
