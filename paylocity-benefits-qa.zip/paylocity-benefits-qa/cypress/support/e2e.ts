// Global support file, loaded before every spec.
import "./commands";

// Uncomment if you want uncaught app exceptions to fail tests instead of
// being swallowed. Useful when hunting for JS errors as part of the bug hunt.
// Cypress.on("uncaught:exception", () => false);
