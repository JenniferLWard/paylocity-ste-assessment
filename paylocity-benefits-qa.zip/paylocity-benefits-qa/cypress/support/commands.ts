/// <reference types="cypress" />

// Wraps the app's Basic auth token header so API specs don't repeat it everywhere.
Cypress.Commands.add("apiRequest", (method: string, path: string, body?: object) => {
  return cy.request({
    method,
    url: `${Cypress.config("baseUrl")}${path}`,
    headers: {
      Authorization: `Basic ${Cypress.env("AUTH_TOKEN")}`,
      "Content-Type": "application/json",
    },
    body,
    failOnStatusCode: false, // let tests assert on status themselves, including expected failures
  });
});

declare global {
  namespace Cypress {
    interface Chainable {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      apiRequest(method: string, path: string, body?: object): Chainable<Cypress.Response<any>>;
    }
  }
}

export {};
