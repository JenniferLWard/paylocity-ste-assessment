// Page Object for the Benefits Dashboard. Update selectors once you inspect
// the real DOM, these are written against the visible structure from the
// screenshots and are the first thing to verify once you're in the app.
class BenefitsDashboardPage {
  visit() {
    cy.visit("/Benefits");
    return this;
  }

  get addEmployeeButton() {
    return cy.contains("button", "Add Employee");
  }

  get employeeRows() {
    return cy.get("table tbody tr");
  }

  rowByName(firstName: string, lastName: string) {
    return this.employeeRows.contains("tr", firstName).contains("tr", lastName);
  }

  editButtonForRow(firstName: string, lastName: string) {
    return this.rowByName(firstName, lastName).find('[aria-label="edit"], button:has(svg)').first();
  }

  deleteButtonForRow(firstName: string, lastName: string) {
    return this.rowByName(firstName, lastName).contains("button", "×");
  }

  fillEmployeeForm(fields: { firstName?: string; lastName?: string; dependents?: string }) {
    if (fields.firstName !== undefined) {
      cy.get('input[name="firstName"]').clear().type(fields.firstName);
    }
    if (fields.lastName !== undefined) {
      cy.get('input[name="lastName"]').clear().type(fields.lastName);
    }
    if (fields.dependents !== undefined) {
      cy.get('input[name="dependants"], input[name="dependents"]').clear().type(fields.dependents);
    }
    return this;
  }

  submitForm() {
    cy.contains("button", "Save").click();
    return this;
  }

  cancelForm() {
    cy.contains("button", "Cancel").click();
    return this;
  }

  benefitsCostForRow(firstName: string, lastName: string) {
    return this.rowByName(firstName, lastName).find("td").eq(5); // adjust index to match real column order
  }

  netPayForRow(firstName: string, lastName: string) {
    return this.rowByName(firstName, lastName).find("td").eq(6); // adjust index to match real column order
  }
}

export default new BenefitsDashboardPage();
