class LoginPage {
  visit() {
    cy.visit(Cypress.env("UI_LOGIN_URL") || "/Account/Login");
    return this;
  }

  get usernameInput() {
    return cy.get('input[name="username"], input[type="text"]').first();
  }

  get passwordInput() {
    return cy.get('input[name="password"], input[type="password"]').first();
  }

  get loginButton() {
    return cy.contains("button", /log in|sign in/i);
  }

  login(username: string, password: string) {
    this.usernameInput.type(username);
    this.passwordInput.type(password);
    this.loginButton.click();
    return this;
  }
}

export default new LoginPage();
