import BenefitsDashboardPage from "../../pages/BenefitsDashboardPage";

describe("Add Employee - UI", () => {
  beforeEach(() => {
    // TODO: replace with real login flow once selectors are confirmed,
    // or programmatically set the auth cookie/token if the app supports it.
    BenefitsDashboardPage.visit();
  });

  it("TC-ADD-01: adds an employee with 0 dependents and shows correct calculation", () => {
    cy.fixture("employees").then((employees) => {
      const { firstName, lastName } = employees.validEmployee;

      BenefitsDashboardPage.addEmployeeButton.click();
      BenefitsDashboardPage.fillEmployeeForm({ firstName, lastName, dependents: "0" });
      BenefitsDashboardPage.submitForm();

      BenefitsDashboardPage.rowByName(firstName, lastName).should("be.visible");
      // Expected benefits cost for 0 dependents: 1000/26 = 38.4615... -> displayed as 38.46
      BenefitsDashboardPage.benefitsCostForRow(firstName, lastName).should("contain", "38.46");
    });
  });

  it("TC-ADD-07: rejects negative dependent count", () => {
    cy.fixture("employees").then((employees) => {
      const { firstName, lastName, dependants } = employees.negativeDependents;

      BenefitsDashboardPage.addEmployeeButton.click();
      BenefitsDashboardPage.fillEmployeeForm({
        firstName,
        lastName,
        dependents: String(dependants),
      });
      BenefitsDashboardPage.submitForm();

      // Document actual behavior here once observed. Flip this assertion
      // to match reality, then link the bug ID in a comment if it fails
      // the acceptance criteria.
      BenefitsDashboardPage.rowByName(firstName, lastName).should("not.exist");
    });
  });

  it("TC-CALC-03: cumulative rounding check across dependent counts", () => {
    // Exploratory: add employees with 0 through 10 dependents and log
    // the displayed benefits cost for each, to see where/if rounding
    // drift shows up as dependent count climbs.
    cy.fixture("employees").then((employees) => {
      for (let count = 0; count <= 10; count++) {
        const firstName = `Round${count}`;
        const lastName = "Test";

        BenefitsDashboardPage.addEmployeeButton.click();
        BenefitsDashboardPage.fillEmployeeForm({
          firstName,
          lastName,
          dependents: String(count),
        });
        BenefitsDashboardPage.submitForm();

        BenefitsDashboardPage.benefitsCostForRow(firstName, lastName).then(($cell) => {
          const expected = 1000 / 26 + count * (500 / 26);
          cy.log(`Dependents: ${count} | Displayed: ${$cell.text()} | Hand-calculated: ${expected.toFixed(4)}`);
        });
      }
    });
  });
});
