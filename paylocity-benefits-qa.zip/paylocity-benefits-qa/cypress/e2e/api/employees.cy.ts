describe("Employees API", () => {
  it("TC-API-01: GET employees returns 200 with valid auth", () => {
    cy.apiRequest("GET", "/api/employees").then((res) => {
      expect(res.status).to.eq(200);
    });
  });

  it("TC-API-11: server-side validation bypass check, negative dependants", () => {
    cy.apiRequest("POST", "/api/employees", {
      firstName: "Api",
      lastName: "NegativeTest",
      username: `apiNeg${Date.now()}`,
      dependants: -1,
    }).then((res) => {
      // Document actual behavior. If this is not 400, that's the bug:
      // client-side-only validation with no server-side enforcement.
      cy.log(`Status: ${res.status}`);
      cy.log(`Body: ${JSON.stringify(res.body)}`);
    });
  });

  it("Regression: read-only-looking fields are silently ignored (salary, username, id)", () => {
    const submittedSalary = 10;
    const submittedUsername = `shouldBeIgnored${Date.now()}`;

    cy.apiRequest("POST", "/api/employees", {
      firstName: "ReadOnly",
      lastName: "FieldTest",
      username: submittedUsername,
      dependants: 0,
      salary: submittedSalary,
    }).then((res) => {
      expect(res.status).to.eq(200);
      // Confirms the previously-filed bug: these values get overwritten server-side.
      expect(res.body.salary).to.not.eq(submittedSalary);
    });
  });

  it("Regression: expiration accepts a past date with no validation", () => {
    cy.apiRequest("POST", "/api/employees", {
      firstName: "Expired",
      lastName: "DateTest",
      username: `expTest${Date.now()}`,
      dependants: 0,
      expiration: "2009-01-21T18:15:43.446Z",
    }).then((res) => {
      expect(res.status).to.eq(200); // documents the bug; should be 400 once fixed
      expect(res.body.expiration).to.eq("2009-01-21T18:15:43.446Z");
    });
  });

  it("Regression: dependants null/omitted returns 405 instead of a validation error", () => {
    cy.apiRequest("POST", "/api/employees", {
      firstName: "Missing",
      lastName: "Dependants",
      username: `missingDep${Date.now()}`,
    }).then((res) => {
      cy.log(`Status: ${res.status}`); // documents the bug; should be 400, not 405
    });
  });
});
