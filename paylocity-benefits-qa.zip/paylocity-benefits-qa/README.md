# Paylocity Benefits Dashboard - QA Automation

Automated UI and API test suites for the STE Bug-Finding Challenge, implemented in both **Cypress** and **Playwright**. Both frameworks are included deliberately: this mirrors a real migration scenario (Cypress as the existing standard, Playwright as the direction the team wants to move), so both suites cover the same test cases side by side for direct comparison.

## Structure

```
cypress/
  e2e/
    api/          API specs
    ui/            UI specs
  pages/           Page Object Model classes
  fixtures/        Reusable test data
  support/         Custom commands, global config

playwright/
  tests/
    api/           API specs
    ui/            UI specs
  pages/           Page Object Model classes
  fixtures/        Reusable test data

.github/workflows/tests.yml   CI pipeline running both suites on push/PR
```

## Setup

1. `npm install`
2. Copy `.env.example` to `.env` and fill in the real login credentials and auth token (provided separately, never commit this file).
3. Cypress: `npm run cy:open` (interactive) or `npm run cy:run` (headless)
4. Playwright: `npm run pw:install` once, then `npm run pw:test`. View the HTML report with `npm run pw:report`.

## Test case mapping

Test IDs in spec files (e.g. `TC-ADD-01`, `TC-API-11`) correspond to the test case document tracked separately. Specs marked "Regression" encode confirmed bugs found during exploratory testing and assert the actual (buggy) behavior, so they'll flip to passing once the underlying bug is fixed, functioning as living regression coverage.

## Notes on selectors

Page Object selectors are written against the visible DOM structure from initial exploration and are flagged with `TODO` where they'll need confirming once the real app is inspected directly (DevTools/React DevTools). Update the Page Object files rather than the specs themselves, that's the whole point of the pattern, one place to fix a selector instead of every test that uses it.

## CI

GitHub Actions runs both suites on every push and PR to `main`. Secrets (`BASE_URL`, `AUTH_TOKEN`, etc.) are configured in the repo's Settings > Secrets, not committed.
