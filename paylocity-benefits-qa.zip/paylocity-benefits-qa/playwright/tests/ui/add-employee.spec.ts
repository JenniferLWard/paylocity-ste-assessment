import { test, expect } from "@playwright/test";
import { BenefitsDashboardPage } from "../../pages/BenefitsDashboardPage";
import employees from "../../fixtures/employees.json";

test.describe("Add Employee - UI", () => {
  test.beforeEach(async ({ page }) => {
    // TODO: replace with real login flow once selectors are confirmed.
    const dashboard = new BenefitsDashboardPage(page);
    await dashboard.goto();
  });

  test("TC-ADD-01: adds an employee with 0 dependents and shows correct calculation", async ({ page }) => {
    const dashboard = new BenefitsDashboardPage(page);
    const { firstName, lastName } = employees.validEmployee;

    await dashboard.addEmployeeButton.click();
    await dashboard.fillEmployeeForm({ firstName, lastName, dependents: "0" });
    await dashboard.submitForm();

    await expect(dashboard.rowByName(firstName, lastName)).toBeVisible();
    // Expected benefits cost for 0 dependents: 1000/26 = 38.4615... -> displayed as 38.46
    await expect(dashboard.benefitsCostForRow(firstName, lastName)).toContainText("38.46");
  });

  test("TC-ADD-07: rejects negative dependent count", async ({ page }) => {
    const dashboard = new BenefitsDashboardPage(page);
    const { firstName, lastName, dependants } = employees.negativeDependents;

    await dashboard.addEmployeeButton.click();
    await dashboard.fillEmployeeForm({ firstName, lastName, dependents: String(dependants) });
    await dashboard.submitForm();

    // Document actual behavior once observed, flip assertion to match reality.
    await expect(dashboard.rowByName(firstName, lastName)).toHaveCount(0);
  });

  test("TC-CALC-03: cumulative rounding check across dependent counts", async ({ page }) => {
    const dashboard = new BenefitsDashboardPage(page);

    for (let count = 0; count <= 10; count++) {
      const firstName = `Round${count}`;
      const lastName = "Test";

      await dashboard.addEmployeeButton.click();
      await dashboard.fillEmployeeForm({ firstName, lastName, dependents: String(count) });
      await dashboard.submitForm();

      const displayed = await dashboard.benefitsCostForRow(firstName, lastName).textContent();
      const expected = 1000 / 26 + count * (500 / 26);
      console.log(`Dependents: ${count} | Displayed: ${displayed} | Hand-calculated: ${expected.toFixed(4)}`);
    }
  });
});
