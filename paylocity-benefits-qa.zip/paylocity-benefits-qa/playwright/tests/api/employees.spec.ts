import { test, expect, request } from "@playwright/test";

const authHeader = { Authorization: `Basic ${process.env.AUTH_TOKEN}`, "Content-Type": "application/json" };

test.describe("Employees API", () => {
  test("TC-API-01: GET employees returns 200 with valid auth", async ({ request: apiRequest }) => {
    const res = await apiRequest.get("/api/employees", { headers: authHeader });
    expect(res.status()).toBe(200);
  });

  test("TC-API-11: server-side validation bypass check, negative dependants", async ({ request: apiRequest }) => {
    const res = await apiRequest.post("/api/employees", {
      headers: authHeader,
      data: {
        firstName: "Api",
        lastName: "NegativeTest",
        username: `apiNeg${Date.now()}`,
        dependants: -1,
      },
    });
    // Document actual behavior. If this is not 400, that's the bug.
    console.log(`Status: ${res.status()}`);
    console.log(`Body: ${await res.text()}`);
  });

  test("Regression: read-only-looking fields are silently ignored", async ({ request: apiRequest }) => {
    const submittedSalary = 10;
    const res = await apiRequest.post("/api/employees", {
      headers: authHeader,
      data: {
        firstName: "ReadOnly",
        lastName: "FieldTest",
        username: `shouldBeIgnored${Date.now()}`,
        dependants: 0,
        salary: submittedSalary,
      },
    });
    expect(res.status()).toBe(200);
    const body = await res.json();
    expect(body.salary).not.toBe(submittedSalary);
  });

  test("Regression: expiration accepts a past date with no validation", async ({ request: apiRequest }) => {
    const res = await apiRequest.post("/api/employees", {
      headers: authHeader,
      data: {
        firstName: "Expired",
        lastName: "DateTest",
        username: `expTest${Date.now()}`,
        dependants: 0,
        expiration: "2009-01-21T18:15:43.446Z",
      },
    });
    expect(res.status()).toBe(200); // documents the bug; should be 400 once fixed
    const body = await res.json();
    expect(body.expiration).toBe("2009-01-21T18:15:43.446Z");
  });

  test("Regression: dependants null/omitted returns 405 instead of a validation error", async ({ request: apiRequest }) => {
    const res = await apiRequest.post("/api/employees", {
      headers: authHeader,
      data: {
        firstName: "Missing",
        lastName: "Dependants",
        username: `missingDep${Date.now()}`,
      },
    });
    console.log(`Status: ${res.status()}`); // documents the bug; should be 400, not 405
  });
});
