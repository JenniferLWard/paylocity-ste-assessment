import { Page, Locator } from "@playwright/test";

// Mirrors the Cypress BenefitsDashboardPage object 1:1, so the two suites
// stay easy to compare and easy to hand off if they migrate fully to
// Playwright later. Update selectors once the real DOM is confirmed.
export class BenefitsDashboardPage {
  readonly page: Page;
  readonly addEmployeeButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.addEmployeeButton = page.getByRole("button", { name: "Add Employee" });
  }

  async goto() {
    await this.page.goto("/Benefits");
  }

  rowByName(firstName: string, lastName: string): Locator {
    return this.page
      .locator("table tbody tr")
      .filter({ hasText: firstName })
      .filter({ hasText: lastName });
  }

  async fillEmployeeForm(fields: { firstName?: string; lastName?: string; dependents?: string }) {
    if (fields.firstName !== undefined) {
      await this.page.locator('input[name="firstName"]').fill(fields.firstName);
    }
    if (fields.lastName !== undefined) {
      await this.page.locator('input[name="lastName"]').fill(fields.lastName);
    }
    if (fields.dependents !== undefined) {
      await this.page
        .locator('input[name="dependants"], input[name="dependents"]')
        .fill(fields.dependents);
    }
  }

  async submitForm() {
    await this.page.getByRole("button", { name: "Save" }).click();
  }

  async cancelForm() {
    await this.page.getByRole("button", { name: "Cancel" }).click();
  }

  benefitsCostForRow(firstName: string, lastName: string): Locator {
    return this.rowByName(firstName, lastName).locator("td").nth(5); // adjust index to match real column order
  }

  netPayForRow(firstName: string, lastName: string): Locator {
    return this.rowByName(firstName, lastName).locator("td").nth(6); // adjust index to match real column order
  }
}
