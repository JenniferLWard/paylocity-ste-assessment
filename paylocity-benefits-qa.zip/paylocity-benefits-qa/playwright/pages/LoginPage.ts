import { Page } from "@playwright/test";

export class LoginPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async goto() {
    await this.page.goto(process.env.UI_LOGIN_URL || "/Account/Login");
  }

  async login(username: string, password: string) {
    await this.page.locator('input[name="username"], input[type="text"]').first().fill(username);
    await this.page.locator('input[name="password"], input[type="password"]').first().fill(password);
    await this.page.getByRole("button", { name: /log in|sign in/i }).click();
  }
}
